export type AnalyseRequest = {
  title: string;
  company: string;
  description: string;
  date_posted?: string;
};

export type AnalyseResponse = {
  ghost_score: number;
  verdict: string;
  confidence: number;
  reasons: string[];
  features?: {
    age_days?: number;
    vagueness_score?: number;
    specificity_score?: number;
    max_similarity?: number;
    duplicate_count?: number;
  };
};
