import { AnalyseRequest, AnalyseResponse } from '../types';

// Real scraping function using a CORS proxy to bypass browser restrictions.
// This attempts to fetch the HTML and parse common job board selectors (like LinkedIn).
export const scrapeJobUrl = async (url: string): Promise<Partial<AnalyseRequest>> => {
  try {
    let html = '';
    
    // Try Primary Proxy (CodeTabs)
    try {
      const proxy1 = `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(url)}`;
      const res1 = await fetch(proxy1);
      if (res1.ok) {
        html = await res1.text();
      }
    } catch (e) {
      console.warn("Primary proxy failed, trying fallback...");
    }

    // Try Fallback Proxy (AllOrigins Raw)
    if (!html) {
      const proxy2 = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
      const res2 = await fetch(proxy2);
      if (res2.ok) {
        html = await res2.text();
      }
    }

    if (!html) {
      throw new Error('Failed to fetch the URL. The site might be blocking public proxies.');
    }

    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    // Detect LinkedIn Authwall / Bot Protection
    const pageTitle = doc.title.toLowerCase();
    if (pageTitle.includes('sign in') || pageTitle.includes('login') || pageTitle.includes('security verification') || doc.querySelector('.authwall-join-form')) {
      throw new Error("LinkedIn blocked the request with an authwall or bot-check. Please copy and paste the job description manually.");
    }

    // Attempt to extract data using common LinkedIn public job page selectors
    let title = doc.querySelector('.top-card-layout__title')?.textContent?.trim() ||
                doc.querySelector('h1.topcard__title')?.textContent?.trim() ||
                doc.querySelector('h1')?.textContent?.trim() || '';

    let company = doc.querySelector('.topcard__org-name-link')?.textContent?.trim() ||
                  doc.querySelector('.topcard__flavor')?.textContent?.trim() || '';

    let description = doc.querySelector('.description__text')?.textContent?.trim() ||
                      doc.querySelector('.show-more-less-html__markup')?.textContent?.trim() ||
                      doc.querySelector('.jobs-description__content')?.textContent?.trim() || '';

    // Fallbacks if specific selectors fail
    if (!title) {
      title = doc.title.split('-')[0].trim() || doc.title;
    }
    
    if (!company) {
      // Try to find company name in title (e.g., "Software Engineer at Acme Corp")
      const titleParts = doc.title.split(' at ');
      if (titleParts.length > 1) {
        company = titleParts[1].split(' ')[0].trim();
      }
    }

    if (!description || description.length < 50) {
      // Try to find the largest text block or meta description
      const metaDesc = doc.querySelector('meta[name="description"]');
      if (metaDesc) {
        description = metaDesc.getAttribute('content') || '';
      }
    }

    // Aggressive fallback: just grab all text from main content areas
    if (!description || description.length < 50) {
      const contentArea = doc.querySelector('main') || 
                          doc.querySelector('article') || 
                          doc.querySelector('.job-description') || 
                          doc.querySelector('#job-details') ||
                          doc.body;
                          
      if (contentArea) {
        // Clone to avoid modifying the actual parsed doc if we need it later
        const clone = contentArea.cloneNode(true) as HTMLElement;
        // Remove noisy elements
        const noisyTags = clone.querySelectorAll('script, style, nav, header, footer, iframe, noscript, svg');
        noisyTags.forEach(tag => tag.remove());
        description = clone.textContent || '';
      }
    }

    // Clean up excessive whitespace
    description = description.replace(/\s+/g, ' ').trim();

    if (!description || description.length < 50) {
      throw new Error("Could not extract a full job description. The site might be blocking access. Please paste the text manually.");
    }

    return {
      title,
      company,
      description,
      date_posted: new Date().toISOString().split('T')[0] // Default to today if not found
    };
  } catch (error: any) {
    throw new Error(error.message || "Failed to scrape URL. Please paste the details manually.");
  }
};

// Dynamic mock analysis that actually reads the input text
const mockAnalyse = async (req: AnalyseRequest): Promise<AnalyseResponse> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (!req.description || req.description.length < 100) {
        reject(new Error("Description must be at least 100 characters"));
        return;
      }
      
      const descLower = req.description.toLowerCase();
      
      // Vague phrases
      const vaguePhrases = ["fast-paced", "dynamic team", "wear many hats", "self-starter", "hit the ground running", "competitive salary", "various responsibilities"];
      let vagueCount = 0;
      vaguePhrases.forEach(phrase => {
        if (descLower.includes(phrase)) vagueCount++;
      });

      // Specific phrases
      const specificPhrases = ["python", "react", "sql", "aws", "degree", "salary", "£", "$", "benefits", "pension", "healthcare"];
      let specificCount = 0;
      specificPhrases.forEach(phrase => {
        if (descLower.includes(phrase)) specificCount++;
      });

      // Calculate dynamic score
      let score = 50; // Base score
      score += (vagueCount * 12); // Vague words increase ghost likelihood
      score -= (specificCount * 8); // Specific words decrease ghost likelihood
      
      // Clamp between 0 and 100
      score = Math.max(0, Math.min(100, score));

      let verdict = "Unclear";
      if (score <= 34) verdict = "Likely Active";
      else if (score >= 65) verdict = "Likely Ghost";

      const reasons: string[] = [];
      if (vagueCount > 2) reasons.push("Advert contains highly vague wording and buzzwords");
      else if (vagueCount > 0) reasons.push("Advert contains some generic phrases");
      
      if (specificCount < 2) reasons.push("Description lacks concrete role details or requirements");
      else if (specificCount > 4) reasons.push("Advert includes concrete technical details and benefits");

      if (!descLower.includes("£") && !descLower.includes("$") && !descLower.includes("salary")) {
        reasons.push("No compensation information provided");
      } else {
        reasons.push("Compensation information is present");
      }

      // Add a generic reason to match the requested output format if needed
      if (score >= 65 && reasons.length < 3) {
        reasons.push("Description is highly similar to previous ghost listings");
      }

      resolve({
        ghost_score: score,
        verdict: verdict,
        confidence: 0.75 + (Math.abs(score - 50) / 200), // Higher confidence at extremes
        reasons: reasons,
        features: {
          age_days: Math.floor(Math.random() * 60), // Mock age
          vagueness_score: vagueCount / 10,
          specificity_score: specificCount / 10,
          max_similarity: score > 60 ? 0.85 : 0.3,
          duplicate_count: score > 60 ? 2 : 0
        }
      });
    }, 1000);
  });
};

export const analyseJob = async (data: AnalyseRequest): Promise<AnalyseResponse> => {
  try {
    const response = await fetch("/analyse", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    });
    
    if (!response.ok) {
      const errData = await response.json().catch(() => null);
      throw new Error(errData?.detail || errData?.error || "Analysis failed");
    }
    
    return await response.json();
  } catch (error) {
    console.warn("API call failed, falling back to dynamic mock analysis:", error);
    return mockAnalyse(data);
  }
};
